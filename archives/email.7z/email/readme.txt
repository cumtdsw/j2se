本项目演示Java的邮件操作，必须下载JavaMail包和Activation包，并加入到项目中，Google之。

很好的一系列博客：http://www.cnblogs.com/qianru/archive/2010/10/24/1859742.html

发送邮件需要STMP服务器，一般邮件提供商均提供。

收邮件推荐使用IMAP协议